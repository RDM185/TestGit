
-- =============================================  
-- Author:    
-- Create date:  
-- Description: 
-- =============================================  

CREATE PROCEDURE [dbo].[udspGetImportStepPaged]   
 -- Add the parameters for the stored procedure here  
 @Start int,  
 @PageSize int,  
 @SearchTerm varchar(256)=null,  
 @Action varchar(256)=null,  
 @TotalCount INT Output  

AS  
BEGIN  
if(@SearchTerm = '')  
	BEGIN  
	  SELECT TOP (@PageSize) * from   
	  (  
	  Select RowID=ROW_NUMBER() over (order by step_k desc), importName, action, stepOrder, parameter1, isnull(parameter2,'N/A') as parameter2, Isnull(parameter3,'N/A') as parameter3
	  ,isnull(parameter4,'N/A')as parameter4, isnull(parameter5,'N/A') as parameter5, isnull(parameter6,'N/A') as parameter6, isnull(parameter7,'N/A') as parameter7
	  from C_ImportSteps  inner Join C_ImportJobs on C_ImportJobs.import_k=C_ImportSteps.import_k  
	  )
	  A Where A.RowID>=(@Start)  
	  Select @TotalCount=COUNT(step_k) FROM  C_ImportSteps  
	  inner Join C_ImportJobs on C_ImportJobs.import_k=C_ImportSteps.import_k  
	END  

ELSE  
	BEGIN  
	  SELECT TOP (@PageSize) * from   
	  (  
	   Select RowID=ROW_NUMBER() over (order by step_k desc), importName, action, stepOrder, parameter1, isnull(parameter2,'N/A') as parameter2, Isnull(parameter3,'N/A') as parameter3
	   ,isnull(parameter4,'N/A')as parameter4, isnull(parameter5,'N/A') as parameter5, isnull(parameter6,'N/A') as parameter6, isnull(parameter7,'N/A') as parameter7
	   from C_ImportSteps  inner Join C_ImportJobs on C_ImportJobs.import_k=C_ImportSteps.import_k  
	   where (action like '%' + @SearchTerm + '%' )  
	  )  
	  A Where A.RowID>=(@Start)  
	  Select @TotalCount=COUNT(step_k) FROM  C_ImportSteps  
	  inner Join C_ImportJobs on C_ImportJobs.import_k=C_ImportSteps.import_k  
	  where (action like '%' + @SearchTerm + '%' )   
	END  
      
END  
  
---------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------

        
-- =============================================            
-- Author:          
-- =============================================            
CREATE PROCEDURE udspMstImportStepsInsert            
 @import_k int,            
 @action varchar(50),       
 @stepOrder varchar(50)= null,      
 @parameter1 varchar(50),           
 @parameter2 varchar(50) =null,            
 @parameter3 varchar (50)=null,              
 @parameter4 varchar(50)= null ,        
 @parameter5 varchar(50)= null,    
 @parameter6 varchar(50)= null,    
 @parameter7 varchar(50)= null   
        
AS            
BEGIN            
 DECLARE   @error_number INT, @ErMessage NVARCHAR(2048), @ErSeverity INT, @ErState INT            
 BEGIN TRY              
  INSERT INTO C_ImportSteps            
           (            
     [import_k],      
     [action],      
     [stepOrder],            
     [parameter1],          
     [parameter2],            
     [parameter3],          
     [parameter4],        
     [parameter5],    
  [parameter6],    
  [parameter7]    
          )            
  VALUES            
           (@import_k, @action, @stepOrder, @parameter1, @parameter2, @parameter3, @parameter4, @parameter5, @parameter6, @parameter7            
           )            
           set @error_number = 0            
           set @ErMessage = ''            
 END TRY             
 BEGIN CATCH              
  SELECT @error_number = ERROR_NUMBER(), @ErMessage = ERROR_MESSAGE(),  @ErSeverity = ERROR_SEVERITY(), @ErState = ERROR_STATE()              
              
  IF @error_number = 2601 -- check constraint violation               
   BEGIN            
    set @error_number = 2601                
    set @ErMessage = 'stepOrder '+ @stepOrder +' already exists, please check the record...'            
   END              
  ELSE -- some other "untrapped" error has occured               
  BEGIN             
   RAISERROR (@ErMessage, @ErSeverity, @ErState )            
  END             
 END CATCH            
 select @error_number as ErrorCode, @ErMessage as ErrorMessage            
END            
            
            

