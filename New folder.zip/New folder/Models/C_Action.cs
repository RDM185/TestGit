﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM.Entities.Models
{
    public class C_Action
    {
        [Key]
        public int actions_k { get; set; }
        [Display(Name = "Action")]
        [Required(ErrorMessage = "Please select Action")]
        public string action { get; set; }
    }
}
