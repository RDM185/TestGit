﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM.Entities.ViewModels
{
    public class MstImportStepViewModel
    {
        public long RowID { get; set; }
        public string importName { get; set; }
        public string action { get; set; }
        public string stepOrder { get; set; }
        public string parameter1 { get; set; }
        public string parameter2 { get; set; }
        public string parameter3 { get; set; }
        public string parameter4 { get; set; }
        public string parameter5 { get; set; }
        public string parameter6 { get; set; }
        public string parameter7 { get; set; }

    }
}
