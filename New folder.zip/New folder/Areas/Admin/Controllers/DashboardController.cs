﻿using PM.Entities.DataAccess;
using PM.Entities.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PM.Web.Areas.Admin.Controllers
{
    public class DashboardController : Controller
    {
        MstFileUploadEngineManageModel ObjModel = new MstFileUploadEngineManageModel();
        dalDropDownList Objddl = new dalDropDownList();
        public ActionResult Index()
        {
            ObjModel.MstActionDDL = Objddl.GetActionDDL();
            ObjModel.MstImportJobDDL = Objddl.GetImportJobDDL();
            return View();
        }
    }
}