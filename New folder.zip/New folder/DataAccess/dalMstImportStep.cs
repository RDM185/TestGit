﻿using PM.Entities.Models;
using PM.Entities.Utilities;
using PM.Entities.ViewModels;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PM.Entities.DataAccess
{
    public class dalMstImportStep
    {
        EFDBContext _Db = new EFDBContext();
        public IEnumerable<MstImportStepViewModel> GetImportStepList(int PageNo, int PageSize, out int TotalRows, string Action = "", string SearchTerm = "")
        {
            List<MstImportStepViewModel> objList = new List<MstImportStepViewModel>();
            if (SearchTerm != null)
            {
                SearchTerm = Regex.Replace(SearchTerm, @"\s+", " ");
            }

            var parAction = new SqlParameter("@Action", Action != null ? Action : DBNull.Value.ToString());
            var parSearchTerm = new SqlParameter("@SearchTerm", SearchTerm);
            var parStart = new SqlParameter("@Start", (PageNo - 1) * PageSize);
            var parPageSize = new SqlParameter("@PageSize", PageSize);
            var spOutput = new SqlParameter
            {
                ParameterName = "@TotalCount",
                SqlDbType = System.Data.SqlDbType.Int,
                Direction = System.Data.ParameterDirection.Output
            };
            objList = _Db.Database.SqlQuery<MstImportStepViewModel>("udspGetImportStepPaged @Start, @PageSize, @SearchTerm, @Action, @TotalCount out", parStart, parPageSize, parSearchTerm, parAction, spOutput).ToList();
            TotalRows = int.Parse(spOutput.Value.ToString());
            return objList;
        }
        public string saveImportAPI(C_ImportStepImportAPI Item)
        {
            SPErrorViewModel objStatus = new SPErrorViewModel();

            var parimport_k = new SqlParameter("@import_k", Item.import_k);
            var paraction = new SqlParameter("@action", Item.action);

            var parstepOrder = new SqlParameter("@stepOrder", DBNull.Value);
            if (Item.stepOrder != null)
                parstepOrder = new SqlParameter("@stepOrder", Item.stepOrder);

            var parparameter1 = new SqlParameter("@parameter1", Item.parameter1);

            var parparameter2 = new SqlParameter("@parameter2", DBNull.Value);
            if (Item.parameter2 != null)
                parparameter2 = new SqlParameter("@parameter2", Item.parameter2);

            var parparameter3 = new SqlParameter("@parameter3", DBNull.Value);
            if (Item.parameter3 != null)
                parparameter3 = new SqlParameter("@parameter3", Item.parameter3);

            var parparameter4 = new SqlParameter("@parameter4", DBNull.Value);
            if (Item.parameter4 != null)
                parparameter4 = new SqlParameter("@parameter4", Item.parameter4);

            var parparameter5 = new SqlParameter("@parameter5", DBNull.Value);
            if (Item.parameter5 != null)
                parparameter5 = new SqlParameter("@parameter5", Item.parameter5);

            var parparameter6 = new SqlParameter("@parameter6", DBNull.Value);
            if (Item.parameter6 != null)
                parparameter6 = new SqlParameter("@parameter6", Item.parameter6);

            var parparameter7 = new SqlParameter("@parameter7", DBNull.Value);
            if (Item.parameter7 != null)
                parparameter7 = new SqlParameter("@parameter7", Item.parameter7);

            objStatus = _Db.Database.SqlQuery<SPErrorViewModel>("udspMstImportStepsInsert @import_k, @action, @stepOrder, @parameter1, @parameter2, @parameter3, @parameter4, @parameter5, @parameter6, @parameter7", parimport_k, paraction, parstepOrder, parparameter1, parparameter2, parparameter3, parparameter4, parparameter5, parparameter6, parparameter7).FirstOrDefault();
            return objStatus.ErrorCode + objStatus.ErrorMessage;
        }
        public string saveMappingMove(C_ImportStepMappingMove Item)
        {
            SPErrorViewModel objStatus = new SPErrorViewModel();

            var parimport_k = new SqlParameter("@import_k", Item.import_k);
            var paraction = new SqlParameter("@action", Item.action);
            var parstepOrder = new SqlParameter("@stepOrder", Item.stepOrder);
            var parparameter1 = new SqlParameter("@parameter1", Item.parameter1);
            var parparameter2 = new SqlParameter("@parameter2", Item.parameter2);

            var parparameter3 = new SqlParameter("@parameter3", DBNull.Value);
            if (Item.parameter3 != null)
                parparameter3 = new SqlParameter("@parameter3", Item.parameter3);

            var parparameter4 = new SqlParameter("@parameter4", Item.parameter4);

            var parparameter5 = new SqlParameter("@parameter5", DBNull.Value);
            if (Item.parameter5 != null)
                parparameter5 = new SqlParameter("@parameter5", Item.parameter5);

            var parparameter6 = new SqlParameter("@parameter6", DBNull.Value);
            if (Item.parameter6 != null)
                parparameter6 = new SqlParameter("@parameter6", Item.parameter6);

            var parparameter7 = new SqlParameter("@parameter7", DBNull.Value);
            if (Item.parameter7 != null)
                parparameter7 = new SqlParameter("@parameter7", Item.parameter7);

            objStatus = _Db.Database.SqlQuery<SPErrorViewModel>("udspMstImportStepsInsert @import_k, @action, @stepOrder, @parameter1, @parameter2, @parameter3, @parameter4, @parameter5, @parameter6, @parameter7", parimport_k, paraction, parstepOrder, parparameter1, parparameter2, parparameter3, parparameter4, parparameter5, parparameter6, parparameter7).FirstOrDefault();
            return objStatus.ErrorCode + objStatus.ErrorMessage;
        }
        //Importdelimitedfile
        public string saveImportdelimitedfile(C_ImportStepImportdelimitedfile Item)
        {
            SPErrorViewModel objStatus = new SPErrorViewModel();

            var parimport_k = new SqlParameter("@import_k", Item.import_k);
            var paraction = new SqlParameter("@action", Item.action);
            var parstepOrder = new SqlParameter("@stepOrder", Item.stepOrder);
            var parparameter1 = new SqlParameter("@parameter1", Item.parameter1);
            var parparameter2 = new SqlParameter("@parameter2", Item.parameter2);

            var parparameter3 = new SqlParameter("@parameter3", DBNull.Value);
            if (Item.parameter3 != null)
                parparameter3 = new SqlParameter("@parameter3", Item.parameter3);

            var parparameter4 = new SqlParameter("@parameter4", Item.parameter4);

            var parparameter5 = new SqlParameter("@parameter5", DBNull.Value);
            if (Item.parameter5 != null)
                parparameter5 = new SqlParameter("@parameter5", Item.parameter5);

            var parparameter6 = new SqlParameter("@parameter6", DBNull.Value);
            if (Item.parameter6 != null)
                parparameter6 = new SqlParameter("@parameter6", Item.parameter6);

            var parparameter7 = new SqlParameter("@parameter7", DBNull.Value);
            if (Item.parameter7 != null)
                parparameter7 = new SqlParameter("@parameter7", Item.parameter7);

            objStatus = _Db.Database.SqlQuery<SPErrorViewModel>("udspMstImportStepsInsert @import_k, @action, @stepOrder, @parameter1, @parameter2, @parameter3, @parameter4, @parameter5, @parameter6, @parameter7", parimport_k, paraction, parstepOrder, parparameter1, parparameter2, parparameter3, parparameter4, parparameter5, parparameter6, parparameter7).FirstOrDefault();
            return objStatus.ErrorCode + objStatus.ErrorMessage;
        }
        //FTP
        public string saveFTP(C_ImportStepFTP Item)
        {
            SPErrorViewModel objStatus = new SPErrorViewModel();

            var parimport_k = new SqlParameter("@import_k", Item.import_k);
            var paraction = new SqlParameter("@action", Item.action);
            var parstepOrder = new SqlParameter("@stepOrder", Item.stepOrder);
            var parparameter1 = new SqlParameter("@parameter1", Item.parameter1);
            var parparameter2 = new SqlParameter("@parameter2", Item.parameter2);

            var parparameter3 = new SqlParameter("@parameter3", DBNull.Value);
            if (Item.parameter3 != null)
                parparameter3 = new SqlParameter("@parameter3", Item.parameter3);

            var parparameter4 = new SqlParameter("@parameter4", Item.parameter4);

            var parparameter5 = new SqlParameter("@parameter5", DBNull.Value);
            if (Item.parameter5 != null)
                parparameter5 = new SqlParameter("@parameter5", Item.parameter5);

            var parparameter6 = new SqlParameter("@parameter6", DBNull.Value);
            if (Item.parameter6 != null)
                parparameter6 = new SqlParameter("@parameter6", Item.parameter6);

            var parparameter7 = new SqlParameter("@parameter7", DBNull.Value);
            if (Item.parameter7 != null)
                parparameter7 = new SqlParameter("@parameter7", Item.parameter7);

            objStatus = _Db.Database.SqlQuery<SPErrorViewModel>("udspMstImportStepsInsert @import_k, @action, @stepOrder, @parameter1, @parameter2, @parameter3, @parameter4, @parameter5, @parameter6, @parameter7", parimport_k, paraction, parstepOrder, parparameter1, parparameter2, parparameter3, parparameter4, parparameter5, parparameter6, parparameter7).FirstOrDefault();
            return objStatus.ErrorCode + objStatus.ErrorMessage;
        }

    }
}
