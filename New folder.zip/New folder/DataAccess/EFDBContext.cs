﻿using PM.Entities.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM.Entities.DataAccess
{
    public class EFDBContext: DbContext
    {
        public DbSet<C_Action> C_Actions { get; set; }
        public DbSet<C_ImportJob> C_ImportJobs { get; set; }
    }
}
