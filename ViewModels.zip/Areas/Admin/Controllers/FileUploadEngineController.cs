﻿using PM.Entities.DataAccess;
using PM.Entities.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PM.Web.Areas.Admin.Controllers
{

    public class FileUploadEngineController : Controller
    {
        MstFileUploadEngineManageModel ObjModel = new MstFileUploadEngineManageModel();
        dalDropDownList Objddl = new dalDropDownList();
        dalMstImportStep Objdal = new dalMstImportStep();

        public ActionResult Create(string ActionName = "")
        {
            ObjModel.MstActionDDL = Objddl.GetActionList();
            ObjModel.MstImportJobDDL = Objddl.GetImportJobList();
            ObjModel.MstImportMapHeaderDDL = Objddl.GetImportMapHeaderList();
            ObjModel.MstDbConnectionDDL = Objddl.GetDbConnectionList();

            ViewBag.IsPartialView = 0;
            if (Request.IsAjaxRequest())
            {
                
                ViewBag.IsPartialView = 1;
                if (ActionName == "ImportAPI")
                {
                    
                    ObjModel.PartialViewName = "pvImportAPI";
                    return PartialView("pvImportAPI", ObjModel);
                }
                else if(ActionName == "MappingMove")
                {
                    ObjModel.PartialViewName = "pvMappingMove";
                    return PartialView("pvMappingMove", ObjModel);
                }
                else if (ActionName == "Importdelimitedfile")
                {
                    ObjModel.PartialViewName = "pvImportdelimitedfile";
                    return PartialView("pvImportdelimitedfile", ObjModel);
                }
                else
                {
                    ObjModel.PartialViewName = "pvFTP";
                    return PartialView("pvFTP", ObjModel);
                }
            }
            return View(ObjModel);
        }
        [HttpPost]
        public ActionResult Create(MstFileUploadEngineManageModel ItemData)
        {
            if (ModelState.IsValid)
            {

                switch (ItemData.C_ImportSteps.action)
                {
                    case "ImportAPI":
                        ItemData.C_ImportStepImportAPIs.import_k = ItemData.C_ImportSteps.import_k;
                        ItemData.C_ImportStepImportAPIs.action = ItemData.C_ImportSteps.action;
                        ItemData.C_ImportStepImportAPIs.parameter2 = "ToTable:" + ItemData.C_ImportStepImportAPIs.parameter2;
                        ItemData.C_ImportStepImportAPIs.parameter3 = "MapTable:" + ItemData.C_ImportStepImportAPIs.parameter3;
                        ItemData.C_ImportStepImportAPIs.parameter4 = "FromConnectionID:" + ItemData.C_ImportStepImportAPIs.parameter4;
                        break;
                    case "MappingMove":
                        ItemData.C_ImportStepMappingMoves.import_k = ItemData.C_ImportSteps.import_k;
                        ItemData.C_ImportStepMappingMoves.action = ItemData.C_ImportSteps.action;
                        ItemData.C_ImportStepMappingMoves.parameter1 = "FromTable:" + ItemData.C_ImportStepMappingMoves.parameter1;
                        ItemData.C_ImportStepMappingMoves.parameter2 = "DestinationTable:" + ItemData.C_ImportStepMappingMoves.parameter2;
                        ItemData.C_ImportStepMappingMoves.parameter4 = "FromConnectionID:" + ItemData.C_ImportStepMappingMoves.parameter4;
                        ItemData.C_ImportStepMappingMoves.parameter5 = "ToConnectionID:" + ItemData.C_ImportStepMappingMoves.parameter5;
                        break;
                    case "Importdelimitedfile":
                        ItemData.C_ImportStepImportdelimitedfiles.import_k = ItemData.C_ImportSteps.import_k;
                        ItemData.C_ImportStepImportdelimitedfiles.action = ItemData.C_ImportSteps.action;
                        ItemData.C_ImportStepImportdelimitedfiles.parameter2 = "ToTable:" + ItemData.C_ImportStepImportdelimitedfiles.parameter2;
                        ItemData.C_ImportSteps.parameter4 = "MapTable:" + ItemData.C_ImportStepImportdelimitedfiles.parameter4;
                        ItemData.C_ImportSteps.parameter7 = "ConnectionID:" + ItemData.C_ImportStepImportdelimitedfiles.parameter7;
                        break;
                    case "FTP":
                        ItemData.C_ImportStepFTPs.import_k = ItemData.C_ImportSteps.import_k;
                        ItemData.C_ImportStepFTPs.action = ItemData.C_ImportSteps.action;
                        ItemData.C_ImportStepFTPs.parameter1 = "FromTable:" + ItemData.C_ImportStepFTPs.parameter1;
                        ItemData.C_ImportStepFTPs.parameter2 = "DestinationTable:" + ItemData.C_ImportStepFTPs.parameter2;
                        ItemData.C_ImportStepFTPs.parameter4 = "FromConnectionID:" + ItemData.C_ImportStepFTPs.parameter4;
                        ItemData.C_ImportStepFTPs.parameter5 = "ToConnectionID:" + ItemData.C_ImportStepFTPs.parameter5;
                        break;
                    default:
                        ItemData.C_ImportStepFTPs.import_k = ItemData.C_ImportSteps.import_k;
                        ItemData.C_ImportStepFTPs.action = ItemData.C_ImportSteps.action;
                        ItemData.C_ImportStepFTPs.parameter1 = "FromTable:" + ItemData.C_ImportStepFTPs.parameter1;
                        ItemData.C_ImportStepFTPs.parameter2 = "DestinationTable:" + ItemData.C_ImportStepFTPs.parameter2;
                        ItemData.C_ImportStepFTPs.parameter4 = "FromConnectionID:" + ItemData.C_ImportStepFTPs.parameter4;
                        ItemData.C_ImportStepFTPs.parameter5 = "ToConnectionID:" + ItemData.C_ImportStepFTPs.parameter5;
                        break;

                }

                if(ItemData.C_ImportSteps.action== "ImportAPI")
                {
                    TempData["ErrMsg"] = Objdal.saveImportAPI(ItemData.C_ImportStepImportAPIs);
                    if (TempData["Errmsg"].ToString() == "0")
                    {
                        TempData["Errmsg"] = null;
                        return RedirectToAction("Create", "FileUploadEngine");
                    }
                }
                if (ItemData.C_ImportSteps.action == "MappingMove")
                {
                    TempData["ErrMsg"] = Objdal.saveMappingMove(ItemData.C_ImportStepMappingMoves);
                    if (TempData["Errmsg"].ToString() == "0")
                    {
                        TempData["Errmsg"] = null;
                        return RedirectToAction("Create", "FileUploadEngine");
                    }
                }
                if(ItemData.C_ImportSteps.action == "Importdelimitedfile")
                {
                    TempData["ErrMsg"] = Objdal.saveImportdelimitedfile(ItemData.C_ImportStepImportdelimitedfiles);
                    if (TempData["Errmsg"].ToString() == "0")
                    {
                        TempData["Errmsg"] = null;
                        return RedirectToAction("Create", "FileUploadEngine");
                    }
                }
                if (ItemData.C_ImportSteps.action == "FTP")
                {
                    TempData["ErrMsg"] = Objdal.saveFTP(ItemData.C_ImportStepFTPs);
                    if (TempData["Errmsg"].ToString() == "0")
                    {
                        TempData["Errmsg"] = null;
                        return RedirectToAction("Create", "FileUploadEngine");
                    }
                }

            }

            ItemData.MstActionDDL = Objddl.GetActionList();
            ItemData.MstImportJobDDL = Objddl.GetImportJobList();
            ItemData.MstImportMapHeaderDDL = Objddl.GetImportMapHeaderList();
            ItemData.MstDbConnectionDDL = Objddl.GetDbConnectionList();
            ItemData.PartialViewName = ItemData.PartialViewName;
            ViewBag.IsPartialView = 1;
            
            //if (ItemData.C_ImportSteps.action == "ImportAPI")
            //{
            //    return PartialView("pvImportAPI", ItemData);
            //}


            return View(ItemData);
        }

        //public ActionResult GetAction(string ActionName)
        //{
        //    ObjModel.MstActionDDL = Objddl.GetActionList();
        //    ObjModel.MstImportJobDDL = Objddl.GetImportJobList();
        //    ObjModel.MstImportMapHeaderDDL = Objddl.GetImportMapHeaderList();
        //    ObjModel.MstDbConnectionDDL = Objddl.GetDbConnectionList();

        //    if (ActionName == "ImportAPI")
        //    {
        //        return PartialView("pvImportAPI", ObjModel);
        //    }
        //    else
        //    {
        //        return null;

        //    }
        //}

    }
}