﻿using PM.Entities.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM.Entities.DataAccess
{
   
    public class dalDropDownList
    {
        EFDBContext _Db = new EFDBContext();
        public List<MstDbConnectionViewModel> GetDbConnectionList()
        {
            List<MstDbConnectionViewModel> result = new List<MstDbConnectionViewModel>();

            return result = _Db.Database.SqlQuery<MstDbConnectionViewModel>("select connection_k, catalog +'-'+ type  as catalog from C_DbConnections").ToList();
        }
        public List<MstImportMapHeaderViewModel> GetImportMapHeaderList()
        {
            List<MstImportMapHeaderViewModel> result = new List<MstImportMapHeaderViewModel>();

            return result = _Db.Database.SqlQuery<MstImportMapHeaderViewModel>("select importMapHeader_k, importMapName from C_ImportMapHeaders").ToList();
        }
        public List<MstActionViewModel> GetActionList()
        {
            List<MstActionViewModel> result = new List<MstActionViewModel>();
           
            return result = _Db.Database.SqlQuery<MstActionViewModel>("select Actions_k, Action from C_Actions").ToList();
            
            //return result = _db.C_Actions.Select(m => new MstActionViewModel
            //{
            //    actions_k = m.actions_k,
            //    action = m.action
            //}).ToList();


        }
        public List<MstImportJobViewModel> GetImportJobList()
        {
            List<MstImportJobViewModel> result = new List<MstImportJobViewModel>();

            return result = _Db.Database.SqlQuery<MstImportJobViewModel>("select import_k, importName from C_ImportJobs").ToList();
        }
    }
}