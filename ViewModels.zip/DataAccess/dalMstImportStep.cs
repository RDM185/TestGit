﻿using PM.Entities.Models;
using PM.Entities.Utilities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM.Entities.DataAccess
{
    public class dalMstImportStep
    {
        EFDBContext _Db = new EFDBContext();
        public string saveImportAPI(C_ImportStepImportAPI Item)
        {
            SPErrorViewModel objStatus = new SPErrorViewModel();

            var parimport_k = new SqlParameter("@import_k", Item.import_k);
            var paraction = new SqlParameter("@action", Item.action);
            var parstepOrder = new SqlParameter("@stepOrder", Item.stepOrder);
            var parparameter1 = new SqlParameter("@parameter1", Item.parameter1);
            var parparameter2 = new SqlParameter("@parameter2", Item.parameter2);

            var parparameter3 = new SqlParameter("@parameter3", DBNull.Value);
            if (Item.parameter3 != null)
                parparameter3 = new SqlParameter("@parameter3", Item.parameter3);

            var parparameter4 = new SqlParameter("@parameter4", Item.parameter4);

            var parparameter5 = new SqlParameter("@parameter5", DBNull.Value);
            if (Item.parameter5 != null)
                parparameter5 = new SqlParameter("@parameter5", Item.parameter5);

            var parparameter6 = new SqlParameter("@parameter6", DBNull.Value);
            if (Item.parameter6 != null)
                parparameter6 = new SqlParameter("@parameter6", Item.parameter6);

            var parparameter7 = new SqlParameter("@parameter7", DBNull.Value);
            if (Item.parameter7 != null)
                parparameter7 = new SqlParameter("@parameter7", Item.parameter7);

            objStatus = _Db.Database.SqlQuery<SPErrorViewModel>("udspMstImportStepsInsert @import_k, @action, @stepOrder, @parameter1, @parameter2, @parameter3, @parameter4, @parameter5, @parameter6, @parameter7", parimport_k, paraction, parstepOrder, parparameter1, parparameter2, parparameter3, parparameter4, parparameter5, parparameter6, parparameter7).FirstOrDefault();
            return objStatus.ErrorCode + objStatus.ErrorMessage;
        }

        public string saveMappingMove(C_ImportStepMappingMove Item)
        {
            SPErrorViewModel objStatus = new SPErrorViewModel();

            var parimport_k = new SqlParameter("@import_k", Item.import_k);
            var paraction = new SqlParameter("@action", Item.action);
            var parstepOrder = new SqlParameter("@stepOrder", Item.stepOrder);
            var parparameter1 = new SqlParameter("@parameter1", Item.parameter1);
            var parparameter2 = new SqlParameter("@parameter2", Item.parameter2);

            var parparameter3 = new SqlParameter("@parameter3", DBNull.Value);
            if (Item.parameter3 != null)
                parparameter3 = new SqlParameter("@parameter3", Item.parameter3);

            var parparameter4 = new SqlParameter("@parameter4", Item.parameter4);

            var parparameter5 = new SqlParameter("@parameter5", DBNull.Value);
            if (Item.parameter5 != null)
                parparameter5 = new SqlParameter("@parameter5", Item.parameter5);

            var parparameter6 = new SqlParameter("@parameter6", DBNull.Value);
            if (Item.parameter6 != null)
                parparameter6 = new SqlParameter("@parameter6", Item.parameter6);

            var parparameter7 = new SqlParameter("@parameter7", DBNull.Value);
            if (Item.parameter7 != null)
                parparameter7 = new SqlParameter("@parameter7", Item.parameter7);

            objStatus = _Db.Database.SqlQuery<SPErrorViewModel>("udspMstImportStepsInsert @import_k, @action, @stepOrder, @parameter1, @parameter2, @parameter3, @parameter4, @parameter5, @parameter6, @parameter7", parimport_k, paraction, parstepOrder, parparameter1, parparameter2, parparameter3, parparameter4, parparameter5, parparameter6, parparameter7).FirstOrDefault();
            return objStatus.ErrorCode + objStatus.ErrorMessage;
        }

        //Importdelimitedfile
        public string saveImportdelimitedfile(C_ImportStepImportdelimitedfile Item)
        {
            SPErrorViewModel objStatus = new SPErrorViewModel();

            var parimport_k = new SqlParameter("@import_k", Item.import_k);
            var paraction = new SqlParameter("@action", Item.action);
            var parstepOrder = new SqlParameter("@stepOrder", Item.stepOrder);
            var parparameter1 = new SqlParameter("@parameter1", Item.parameter1);
            var parparameter2 = new SqlParameter("@parameter2", Item.parameter2);

            var parparameter3 = new SqlParameter("@parameter3", DBNull.Value);
            if (Item.parameter3 != null)
                parparameter3 = new SqlParameter("@parameter3", Item.parameter3);

            var parparameter4 = new SqlParameter("@parameter4", Item.parameter4);

            var parparameter5 = new SqlParameter("@parameter5", DBNull.Value);
            if (Item.parameter5 != null)
                parparameter5 = new SqlParameter("@parameter5", Item.parameter5);

            var parparameter6 = new SqlParameter("@parameter6", DBNull.Value);
            if (Item.parameter6 != null)
                parparameter6 = new SqlParameter("@parameter6", Item.parameter6);

            var parparameter7 = new SqlParameter("@parameter7", DBNull.Value);
            if (Item.parameter7 != null)
                parparameter7 = new SqlParameter("@parameter7", Item.parameter7);

            objStatus = _Db.Database.SqlQuery<SPErrorViewModel>("udspMstImportStepsInsert @import_k, @action, @stepOrder, @parameter1, @parameter2, @parameter3, @parameter4, @parameter5, @parameter6, @parameter7", parimport_k, paraction, parstepOrder, parparameter1, parparameter2, parparameter3, parparameter4, parparameter5, parparameter6, parparameter7).FirstOrDefault();
            return objStatus.ErrorCode + objStatus.ErrorMessage;
        }
        //FTP
        public string saveFTP(C_ImportStepFTP Item)
        {
            SPErrorViewModel objStatus = new SPErrorViewModel();

            var parimport_k = new SqlParameter("@import_k", Item.import_k);
            var paraction = new SqlParameter("@action", Item.action);
            var parstepOrder = new SqlParameter("@stepOrder", Item.stepOrder);
            var parparameter1 = new SqlParameter("@parameter1", Item.parameter1);
            var parparameter2 = new SqlParameter("@parameter2", Item.parameter2);

            var parparameter3 = new SqlParameter("@parameter3", DBNull.Value);
            if (Item.parameter3 != null)
                parparameter3 = new SqlParameter("@parameter3", Item.parameter3);

            var parparameter4 = new SqlParameter("@parameter4", Item.parameter4);

            var parparameter5 = new SqlParameter("@parameter5", DBNull.Value);
            if (Item.parameter5 != null)
                parparameter5 = new SqlParameter("@parameter5", Item.parameter5);

            var parparameter6 = new SqlParameter("@parameter6", DBNull.Value);
            if (Item.parameter6 != null)
                parparameter6 = new SqlParameter("@parameter6", Item.parameter6);

            var parparameter7 = new SqlParameter("@parameter7", DBNull.Value);
            if (Item.parameter7 != null)
                parparameter7 = new SqlParameter("@parameter7", Item.parameter7);

            objStatus = _Db.Database.SqlQuery<SPErrorViewModel>("udspMstImportStepsInsert @import_k, @action, @stepOrder, @parameter1, @parameter2, @parameter3, @parameter4, @parameter5, @parameter6, @parameter7", parimport_k, paraction, parstepOrder, parparameter1, parparameter2, parparameter3, parparameter4, parparameter5, parparameter6, parparameter7).FirstOrDefault();
            return objStatus.ErrorCode + objStatus.ErrorMessage;
        }

    }
}
