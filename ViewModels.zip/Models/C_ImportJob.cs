﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM.Entities.Models
{
    public class C_ImportJob
    {
        [Key]
        public int import_k { get; set; }
        [Display(Name = "Import Name")]
        [Required(ErrorMessage = "Please select Import Name")]
        public string importName { get; set; }
    }
}
