﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM.Entities.ViewModels
{
    public class MstDbConnectionViewModel
    {
        public int connection_k { get; set; }
        public string catalog { get; set; }
    }
}
