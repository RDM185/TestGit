﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM.Entities.ViewModels
{
    public class MstImportMapHeaderViewModel
    {
        public int importMapHeader_k { get; set; }
        public string importMapName { get; set; }
    }
}
